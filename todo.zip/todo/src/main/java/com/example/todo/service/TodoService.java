package com.example.todo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.todo.exception.InvalidTodoException;
import com.example.todo.exception.TodoNotFoundException;
import com.example.todo.model.Todo;
import com.example.todo.repository.TodoRepository;

@Service
public class TodoService {

    private final TodoRepository todoRepository;

    public TodoService(TodoRepository todoRepository) {
        this.todoRepository = todoRepository;
    }

    // Todoの作成
    public Todo createTodo(String context, Boolean isCompleted) {
    	validation(context, isCompleted);
        
        Todo todo = new Todo(context, isCompleted);
        return todoRepository.save(todo);
    }

    // Todoの全取得
    public List<Todo> getAllTodos() {
        return todoRepository.findAll();
    }

    // TodoのIDで取得
    public Todo getTodoById(int id) {
        return todoRepository.findById(id).orElseThrow(() -> new TodoNotFoundException("Todoが見つかりません"));
    }

    // Todoの更新
    public Todo updateTodo(int id, String context, Boolean isCompleted) {
    	validation(context, isCompleted);

        Todo todo = new Todo(context, isCompleted);
        return todoRepository.update(id, todo).orElseThrow(() -> new TodoNotFoundException("Todoが見つかりません"));
    }

    // Todoの削除
    public void deleteTodo(int id) {
        if (!todoRepository.delete(id)) {
            throw new TodoNotFoundException("Todoが見つかりません");
        }
    }
    
    // バリデーションチェック
    private void validation(String context, Boolean isCompleted) {
    	if (context == null || context.isEmpty()) {
            throw new InvalidTodoException("内容は必ず入力してください");
        }
        if (context.length() < 1 || context.length() > 255) {
            throw new InvalidTodoException("内容は1文字以上、255文字以下で入力してください");
        }
        if (isCompleted == null) {
            throw new InvalidTodoException("完了状態は必ず入力してください");
        }
    }
}
