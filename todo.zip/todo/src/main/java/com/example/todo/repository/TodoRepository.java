package com.example.todo.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.example.todo.model.Todo;

@Repository
public class TodoRepository {
    private final List<Todo> todos = new ArrayList<>();
    private int nextId = 1;

    // Todoを追加
    public Todo save(Todo todo) {
        todo.setId(nextId++);
        todos.add(todo);
        return todo;
    }

    // TodoをIDで取得
    public Optional<Todo> findById(int id) {
        return todos.stream().filter(todo -> todo.getId() == id).findFirst();
    }

    // すべてのTodoを取得
    public List<Todo> findAll() {
        return todos;
    }

    // Todoを更新
    public Optional<Todo> update(int id, Todo newTodo) {
        Optional<Todo> todo = findById(id);
        todo.ifPresent(existingTodo -> {
            existingTodo.setContext(newTodo.getContext());
            existingTodo.setIsCompleted(newTodo.getIsCompleted());
        });
        return todo;
    }

    // Todoを削除
    public boolean delete(int id) {
        return todos.removeIf(todo -> todo.getId() == id);
    }
}
