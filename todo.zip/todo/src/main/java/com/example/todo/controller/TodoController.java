package com.example.todo.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.todo.model.Todo;
import com.example.todo.service.TodoService;

@Controller
@RequestMapping("/todos")
public class TodoController {

    private final TodoService todoService;

    public TodoController(TodoService todoService) {
        this.todoService = todoService;
    }

    @GetMapping
    @ResponseBody
    public List<Todo> getAllTodos() {
        return todoService.getAllTodos();
    }

    @PostMapping
    @ResponseBody
    public Todo createTodo(@RequestParam String context, @RequestParam Boolean isCompleted) {
        return todoService.createTodo(context, isCompleted);
    }

    @GetMapping("/{id}")
    @ResponseBody
    public Todo getTodoById(@PathVariable int id) {
        return todoService.getTodoById(id);
    }

    @PutMapping("/{id}")
    @ResponseBody
    public Todo updateTodo(@PathVariable int id, @RequestParam String context, @RequestParam Boolean isCompleted) {
        return todoService.updateTodo(id, context, isCompleted);
    }

    @DeleteMapping("/{id}")
    public void deleteTodo(@PathVariable int id) {
        todoService.deleteTodo(id);
    }
}
