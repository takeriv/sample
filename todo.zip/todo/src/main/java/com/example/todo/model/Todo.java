package com.example.todo.model;

public class Todo {
    private int id;
    private String context;
    private Boolean isCompleted;

    // コンストラクタ
    public Todo(String context, Boolean isCompleted) {
        this.context = context;
        this.isCompleted = isCompleted;
    }

    // ゲッターとセッター
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public Boolean getIsCompleted() {
        return isCompleted;
    }

    public void setIsCompleted(Boolean isCompleted) {
        this.isCompleted = isCompleted;
    }
}
